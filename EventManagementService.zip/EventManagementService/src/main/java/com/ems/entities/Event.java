package com.ems.entities;

import java.io.Serializable;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateSerializer;

/*import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateDeserializer;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateSerializer;*/

/**
 * @author SP00340556
 *
 */
@Entity
//@JsonSerialize(using = LocalDateSerializer.class)	
//@Table(name="Techm_Event")
public class Event  {

	@Id
	@GeneratedValue
	private int eventId;
//	@Column(name="event_name",unique=true,nullable=false)
	private String name;	
	private LocalDate date;
	private String time;
	private float price;
	private String imageUrl;
	
	/*@Transient
	private String sabari;*/
	 
	@Override
	public String toString() {
		return "Event [eventId=" + eventId + ", name=" + name + ", date=" + date + ", time=" + time + ", price=" + price
				+ ", imageUrl=" + imageUrl + "]";
	}


	@OneToOne(cascade=CascadeType.ALL)
	@JoinColumn(name="location_id")
	private Location location;
	
	
	@OneToMany(fetch=FetchType.LAZY ,targetEntity=Session.class,mappedBy="event")
	private List<Session> sessions =  new ArrayList<>();
	
	
	public List<Session> getSessions() {
		return sessions;
	}

	public void setSessions(List<Session> sessions) {
		this.sessions = sessions;
	}

	public Event(int id, String name, LocalDate date, 
			String time, float price, String imageUrl) {
		super();
		this.eventId = id;
		this.name = name;
		this.date = date;
		this.time = time;
		this.price = price;
		this.imageUrl = imageUrl;
	}
		
	public int getEventId() {
		return eventId;
	}

	public void setEventId(int eventId) {
		this.eventId = eventId;
	}

	public Location getLocation() {
		return location;
	}



	public void setLocation(Location location) {
		this.location = location;
	}



	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public LocalDate getDate() {
		return date;
	}
	public void setDate(LocalDate date) {
		this.date = date;
	}
	public String getTime() {
		return time;
	}
	public void setTime(String time) {
		this.time = time;
	}
	public float getPrice() {
		return price;
	}
	public void setPrice(float price) {
		this.price = price;
	}
	public String getImageUrl() {
		return imageUrl;
	}
	public void setImageUrl(String imageUrl) {
		this.imageUrl = imageUrl;
	}
	
	
	public Event() {
		// TODO Auto-generated constructor stub
	}

	
	
	
}
