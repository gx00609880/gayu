package com.ems.dao;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.Month;
import java.util.ArrayList;
import java.util.List;

import com.ems.model.Event;
import com.ems.model.Location;
import com.ems.model.Session;

public class EventUtil {
	
	public static Event getEventDetails() {
	
		Location location = new Location(1,"1057 DT","London","England");
		
		Session session1 = new Session(1,"Using Angular 4 Pipes",
				"Peter Bacon Darwin",1, "Intermediate","Learn all about the new pipes in Angular 4",
				new String[]{"bradgreen","igorminar","martinfowler"});
				
		Session session2 = new Session(2,"Getting the most out of your dev team",
				"Jeff Cross",1, "Intermediate","We all know that our dev teams work hard, but with",
				new String[]{"johnpapa","bradgreen","igorminar","martinfowler"});
		
		Session session3 = new Session(3,"Angular 4 Performance Metrics",
				"Rob Wormald",2, "Advanced","Angular 4 Performance is hot. In this session, we'll see",
				new String[]{});		
		List<Session> sessions = new ArrayList<>();
		
		sessions.add(session1);
		sessions.add(session2);
		sessions.add(session3);		
		Event event =null;//= new Event(1,"Angular Connect",LocalDate.of(2036, 9,26),"10:00 am",599.99f,
//				 "/assets/images/angularconnect-shield.png",location,sessions);
		
		return event;
	}
}
