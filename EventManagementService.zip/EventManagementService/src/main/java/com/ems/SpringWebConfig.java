package com.ems;

import java.util.Properties;

//import org.apache.tomcat.jdbc.pool.DataSource;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.orm.hibernate5.HibernateTransactionManager;
import org.springframework.orm.hibernate5.LocalSessionFactoryBean;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;

/*@Configuration
@ComponentScan(basePackages= {"com.ems"})
@EnableWebMvc
//@Transactional(propagation=Propagation.REQUIRED)
@PropertySource(value= {"classpath:/application.properties"},ignoreResourceNotFound=true)
Adding this annotation to an @Configuration class imports the Spring
MVC configuration from WebMvcConfigurationSupport 
@EnableTransactionManagement*/
public class SpringWebConfig {

	@Value("${database.drivername}")
	private String driverClassName;
	
	@Value("${database.username}")
	private String username;
	
	@Value("${database.password}")
	private String password;
	
	@Value("${database.url}")
	private String url;
	
	@Value("${hibernate.show_sql}")
	private String showSQL;
	
	@Value("${hibernate.dialect}")
	private String dialect;
		
	@Value("${hibernate.hbm2ddl.auto}")
	private String ddlAuto;
	
	@Value("${entity.packagestoscan}")
	private String packagesToScanEntities;
	
	
	@Bean
	public LocalSessionFactoryBean getSessionFactory() {
		
		LocalSessionFactoryBean localSessionFactoryBean = new LocalSessionFactoryBean();
		
		localSessionFactoryBean.setPackagesToScan(packagesToScanEntities);
		
		//localSessionFactoryBean.setDataSource(getDataSource());
		
		Properties hibernateProperties = new Properties();
		
		hibernateProperties.setProperty("hibernate.show_sql", showSQL);
		hibernateProperties.setProperty("hibernate.dialect",dialect);
		hibernateProperties.setProperty("hibernate.hbm2ddl.auto", ddlAuto);
		
		localSessionFactoryBean.setHibernateProperties(hibernateProperties);		
		
		return localSessionFactoryBean;
		
	}
	
	@Bean
	public HibernateTransactionManager getTransactionManager() {
	
		HibernateTransactionManager hibernateTransactionManager  = new HibernateTransactionManager();
		
		//Return an instance (possibly shared or independent) of the object managed 
		//by this factory.
		hibernateTransactionManager.setSessionFactory(getSessionFactory().getObject());
		
		return hibernateTransactionManager;
	}
	
	/*@Bean
	public DataSource getDataSource() {
		DataSource dataSource = new DataSource();
		dataSource.setUsername(username);
		dataSource.setPassword(password);
		dataSource.setUrl(url);
		dataSource.setDriverClassName(driverClassName);
		return dataSource;			
	}*/
	
	/*@Bean
	public JdbcTemplate jdbcTemplate() {
		JdbcTemplate jdbcTemplate = new JdbcTemplate();
		jdbcTemplate.setDataSource(getDataSource());
		return jdbcTemplate;
	}*/
	
	
	
	
}
