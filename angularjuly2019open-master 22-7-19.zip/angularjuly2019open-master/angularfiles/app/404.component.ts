import { Component } from '@angular/core';

@Component(
    {
        template:'<h1>Error</h1>'
    }
)
export class Error404Component{

}