package com.ems.jpa;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ems.entities.Location;

public interface LocationJPA extends JpaRepository<Location, Integer> {

}
