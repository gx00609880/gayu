package com.ems.pojo;

import java.time.LocalDate;

public class EventLocation {

	private int event_id;
	private String name;	
	private LocalDate date;
	private String time;
	private float price;
	private String imageUrl;
	
	private int loc_id;
	private String address;
	private String city;
	private String country;
	
	public EventLocation() {
		// TODO Auto-generated constructor stub
	}

	public EventLocation(int event_id, String name, LocalDate date, String time, float price, String imageUrl,
			int loc_id, String address, String city, String country) {
		super();
		this.event_id = event_id;
		this.name = name;
		this.date = date;
		this.time = time;
		this.price = price;
		this.imageUrl = imageUrl;
		this.loc_id = loc_id;
		this.address = address;
		this.city = city;
		this.country = country;
	}

	public int getEvent_id() {
		return event_id;
	}

	public void setEvent_id(int event_id) {
		this.event_id = event_id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public LocalDate getDate() {
		return date;
	}

	public void setDate(LocalDate date) {
		this.date = date;
	}

	public String getTime() {
		return time;
	}

	public void setTime(String time) {
		this.time = time;
	}

	public float getPrice() {
		return price;
	}

	public void setPrice(float price) {
		this.price = price;
	}

	public String getImageUrl() {
		return imageUrl;
	}

	public void setImageUrl(String imageUrl) {
		this.imageUrl = imageUrl;
	}

	public int getLoc_id() {
		return loc_id;
	}

	public void setLoc_id(int loc_id) {
		this.loc_id = loc_id;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}
	
	
}
