import { Component, OnInit, Input , Output,EventEmitter} from '@angular/core';

@Component({
  selector: 'events-list-thumbnail',
  templateUrl: './events-thumbnail.component.html',
  styleUrls: ['./events-thumbnail.component.css']
})
export class EventsThumbnailComponent {
@Input('eve') event1;
@Output() event:EventEmitter = new EventEmitter();  
addlistener()
{
  this.event.emit("INDIA");
}

}
