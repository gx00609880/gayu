"use strict";
var Product = /** @class */ (function () {
    function Product(_prodId, _prodName, _prodPrice) {
        this._prodId = _prodId;
        this._prodName = _prodName;
        this._prodPrice = _prodPrice;
    }
    Object.defineProperty(Product.prototype, "prodId", {
        get: function () {
            return this._prodId;
        },
        set: function (prodId) {
            this._prodId = prodId;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(Product.prototype, "prodName", {
        get: function () {
            return this._prodName;
        },
        set: function (prodName) {
            this._prodName = prodName;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(Product.prototype, "prodPrice", {
        get: function () {
            return this._prodPrice;
        },
        set: function (prodPrice) {
            this._prodPrice = prodPrice;
        },
        enumerable: true,
        configurable: true
    });
    return Product;
}());
var product = new Product(101, "Apple Watch", 3243);
product.prodPrice = 34453;
console.log(product.prodPrice);
//# sourceMappingURL=day3demo1.js.map