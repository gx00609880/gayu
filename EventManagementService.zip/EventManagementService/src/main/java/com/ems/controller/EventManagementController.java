package com.ems.controller;

import java.util.List;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.ems.entities.Location;
import com.ems.model.Event;
import com.ems.service.EventService;

@Controller
//@RestController
@RequestMapping("/root")
@CrossOrigin
//@Transactional
public class EventManagementController {
	InitializingBean ib;
	@Autowired
	private EventService eventService;
	
	@GetMapping("/searchlocation/{countryName}")
	@ResponseBody
	public List<Location> searchByLocationCountry(@PathVariable String countryName){
		return eventService.searchByLocationCountry(countryName);
	}
	
	@GetMapping("/updatelocation/{locationId}/{cityName}")
	@ResponseBody
	public boolean updateLocationCity(@PathVariable int locationId,
			 @PathVariable String cityName) {
		return eventService.updateLocationCity(locationId, cityName);
	}

	@DeleteMapping("/deletelocation/{locationId}")
	@ResponseBody
	public boolean deleteLocation(@PathVariable int locationId) {
		return eventService.deleteLocation(locationId);
	}
	
	
	@PostMapping("/locations")
	@ResponseBody
	public boolean insertLocation(@RequestBody List<Location> locations) {		
		return eventService.insertLocation(locations);
		
	}
	
	
	//Handler Method (Endpoint)
//	@RequestMapping(value="/welcome",method=RequestMethod.GET)
	@GetMapping("/welcome")	
	@ResponseBody
	public  String welcome() {
		return "Welcome To Spring World!";
	}
	
	@PostMapping("/insert")	
	@ResponseBody
	public boolean insertEventDetails(@RequestBody Event event) {
		return eventService.insertEventDetails(event);
	}	
	
	//URI Templating Feature - URI Template Variable
	@GetMapping("/eventdetails/{eventId}")
	@ResponseBody
	public com.ems.entities.Event getEventDetails(
			@PathVariable("eventId") int eId) {
		return eventService.getEventDetails(eId);
	}
	
	@GetMapping("/allevents")
	@ResponseBody
	public List<com.ems.entities.Event> getAllEventDetails(){
		return eventService.getAllEventDetails();
	}
}