var todo={
    "name":"Angular Session",
    "completed":true
}
//String templating-string intrerpolation(Angular)
//var status:string="Your Task "+(todo.completed?'IS' : 'IS NOT')+" Completed";
var status:string=`Your Task ${todo.completed?'IS' : 'IS NOT'}`+" Completed";
console.log(status);