package com.ems.pojo;

public class Voters {

	private int voter_id;
	private String voter_name;
	
	public Voters() {
		// TODO Auto-generated constructor stub
	}

	public Voters(int voter_id, String voter_name) {
		super();
		this.voter_id = voter_id;
		this.voter_name = voter_name;
	}

	public int getVoter_id() {
		return voter_id;
	}

	public void setVoter_id(int voter_id) {
		this.voter_id = voter_id;
	}

	public String getVoter_name() {
		return voter_name;
	}

	public void setVoter_name(String voter_name) {
		this.voter_name = voter_name;
	}
	
	
	

	
}
