interface Todo
{
    name:string;
    completed?:boolean;
}
interface ITodoService{
    getAllTodo(id:number):Todo[];
}
abstract class Parent{

 demo():number
{
    return 10;
}
}
export class TodoApp extends Parent implements ITodoService{
    arr:Todo[]=[{name:"gayu"},{name:"b"}];
   /*  id1:number=0;
        age:number=0; */
    constructor(private id:number,private age:number=0)
    {
        super();//calling base class constructor
    /*     this.id1=id;
        this.age=age; */
    }
    getAllTodo(id:number)
    {
        return this.arr;
    }
    demo():number{
        return super.demo()+10;//calling base class method
    }
}
let Todonew=new TodoApp(4);
//var p=new Parent();//cannot create obj for abstract class
Todonew.getAllTodo
var myTodo:Todo={completed:true,name:""};
console.log(myTodo);