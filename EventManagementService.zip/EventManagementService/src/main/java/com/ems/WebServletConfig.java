package com.ems;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.ServletRegistration;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.web.WebApplicationInitializer;
import org.springframework.web.context.support.AnnotationConfigWebApplicationContext;
import org.springframework.web.servlet.DispatcherServlet;

public class WebServletConfig{// implements WebApplicationInitializer {

	//@Override
	public void onStartup(ServletContext servletContext) throws ServletException {
	System.out.println("OnStartup Invoked!");
	//Step1: Configure the IoC Container (ApplicationContext)
	//ClassPathXMLApplicationContext , AnnotationConfigApplicationContext	
	AnnotationConfigWebApplicationContext iocContext = new AnnotationConfigWebApplicationContext();
	
	//Step2: Register the Spring Web Configuration Class into the IoC Context
	iocContext.register(SpringWebConfig.class);
		
	//Step3: Register The DispatcherServlet Into the Dynamic Servlet WEB-Container
	
	ServletRegistration.Dynamic servletRegistration = 
			servletContext.addServlet("ds",new DispatcherServlet(iocContext));
	
	//Step4: Load the DispatcherServlet inside the container at the time of loading
	// the application
	
	servletRegistration.setLoadOnStartup(1);
	
	//Step5: Last Step , Add Url Pattern to redirect the request to DS.
	
	servletRegistration.addMapping("/");
	
	
	}
	
}
