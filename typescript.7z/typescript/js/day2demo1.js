"use strict";
/*  var cont=document.getElementById('container');
function newfnc(el){
    this.count=0;
    el.innerHTML=this.count;
    el.addEventListener('click',()=>{
        this.count+=1;
        el.innerHTML=this.count;
    });
}
new newfnc(cont);//el repersents container  */
var ages = [12, 23, 34, 45].filter(function (x) { return x > 25; });
console.log(ages);
//# sourceMappingURL=day2demo1.js.map