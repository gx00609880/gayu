package com.ems.model;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

/*import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateDeserializer;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateSerializer;*/

//@JsonDeserialize(using = LocalDateDeserializer.class)
	//@JsonSerialize(using = LocalDateSerializer.class)
public class Event {

	private int id;
	private String name;	
	private String date;
	private String time;
	private float price;
	private String imageUrl;
	
	private Location location;
	private List<Session> list = new ArrayList();
	
	public Event(int id, String name, String date, String time, float price, String imageUrl, Location location,
			List<Session> list) {
		super();
		this.id = id;
		this.name = name;
		this.date = date;
		this.time = time;
		this.price = price;
		this.imageUrl = imageUrl;
		this.location = location;
		this.list = list;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public String getTime() {
		return time;
	}
	public void setTime(String time) {
		this.time = time;
	}
	public float getPrice() {
		return price;
	}
	public void setPrice(float price) {
		this.price = price;
	}
	public String getImageUrl() {
		return imageUrl;
	}
	public void setImageUrl(String imageUrl) {
		this.imageUrl = imageUrl;
	}
	public Location getLocation() {
		return location;
	}
	public void setLocation(Location location) {
		this.location = location;
	}
	public List<Session> getList() {
		return list;
	}
	public void setList(List<Session> list) {
		this.list = list;
	}
	
	public Event() {
		// TODO Auto-generated constructor stub
	}

	
	
	
}
