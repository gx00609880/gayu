import { Component } from '@angular/core';
import {EventsListComponent} from './events/events-list.component';
@Component({
  selector: 'app-root',
  //templateUrl: './app.component.html',
  template: '<events-list></events-list>',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'Event-Management-App';
}
