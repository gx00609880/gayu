"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
var Parent = /** @class */ (function () {
    function Parent() {
    }
    Parent.prototype.demo = function () {
        return 10;
    };
    return Parent;
}());
var TodoApp = /** @class */ (function (_super) {
    __extends(TodoApp, _super);
    /*  id1:number=0;
         age:number=0; */
    function TodoApp(id, age) {
        if (age === void 0) { age = 0; }
        var _this = _super.call(this) || this;
        _this.id = id;
        _this.age = age;
        _this.arr = [{ name: "gayu" }, { name: "b" }];
        return _this;
        /*     this.id1=id;
            this.age=age; */
    }
    TodoApp.prototype.getAllTodo = function (id) {
        return this.arr;
    };
    TodoApp.prototype.demo = function () {
        return _super.prototype.demo.call(this) + 10; //calling base class method
    };
    return TodoApp;
}(Parent));
exports.TodoApp = TodoApp;
var Todonew = new TodoApp(4);
//var p=new Parent();//cannot create obj for abstract class
Todonew.getAllTodo;
var myTodo = { completed: true, name: "" };
console.log(myTodo);
//# sourceMappingURL=day2demo2.js.map