import {Component} from '@angular/core';
@Component({
selector:'events-list',
template:`
<h1>{{label}}</h1>
<hr>
<events-list-thumbnail [eve]="event1"></events-list-thumbnail>
`,
styles: ['h1{color:yellow}']
})


export class EventsListComponent
{
label:string="Angular events";
event1 ={
    id:1,
    name:'Angular Connect',
    date:'7/15/2019',
    time: '10:00 am',
    price: 599.99,
    imageUrl: '/assets/images/angularconnect-shield.png',
    location:{
        address: '1057 DT',
        city: 'London',
        country: 'England'
    }
}
}