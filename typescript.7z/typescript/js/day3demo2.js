"use strict";
var todo = {
    "name": "Angular Session",
    "completed": true
};
//String templating-string intrerpolation(Angular)
//var status:string="Your Task "+(todo.completed?'IS' : 'IS NOT')+" Completed";
var status = "Your Task " + (todo.completed ? 'IS' : 'IS NOT') + " Completed";
console.log(status);
//# sourceMappingURL=day3demo2.js.map