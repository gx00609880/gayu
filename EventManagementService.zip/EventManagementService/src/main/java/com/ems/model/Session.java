package com.ems.model;

public class Session {

	private int id;
	private String name;
	private String presenter;
	private float duration;
	private String level;
	private String description;
	private String[] voters;
	
	public Session() {
		// TODO Auto-generated constructor stub
	}
	
	 

	public Session(int id, String name, String presenter, float duration, String level, String description,
			String[] voters) {
		super();
		this.id = id;
		this.name = name;
		this.presenter = presenter;
		this.duration = duration;
		this.level = level;
		this.description = description;
		this.voters = voters;
	}



	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPresenter() {
		return presenter;
	}

	public void setPresenter(String presenter) {
		this.presenter = presenter;
	}

	public float getDuration() {
		return duration;
	}

	public void setDuration(float duration) {
		this.duration = duration;
	}

	public String getLevel() {
		return level;
	}

	public void setLevel(String level) {
		this.level = level;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String[] getVoters() {
		return voters;
	}

	public void setVoters(String[] voters) {
		this.voters = voters;
	}
	
	

}
