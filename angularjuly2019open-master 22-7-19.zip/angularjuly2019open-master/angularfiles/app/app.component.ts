import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  // template:'<events-list></events-list>',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'Sabari Balaji';
}
