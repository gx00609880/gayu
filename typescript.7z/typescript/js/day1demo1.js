"use strict";
var age = "12"; //when u pop up ,it shows any = no typeinference
var names = "gayathri"; //"|" is union
names = 12;
//string-is a primitive type
//String-is a wrapper class
var veg = [false, true]; //nested array
var fruits = [true, "abc", "def"]; //array
var a = fruits[0], b = fruits[1], c = fruits[2]; //
function getData(name, age) {
}
getData("34");
/* for(let tmp in fruits)
{

    console.log(fruits[tmp]);
} */
for (var _i = 0, fruits_1 = fruits; _i < fruits_1.length; _i++) {
    var tmp = fruits_1[_i];
    console.log(tmp);
}
function demo() {
    if (true) {
        var price = 10.5;
    }
    console.log(price);
}
demo();
var Employee = /** @class */ (function () {
    function Employee() {
    }
    return Employee;
}());
age = "34"; //typeinference
console.log(age);
//# sourceMappingURL=day1demo1.js.map