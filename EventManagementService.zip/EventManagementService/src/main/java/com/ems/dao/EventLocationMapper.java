package com.ems.dao;

import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;

import org.springframework.jdbc.core.RowMapper;

import com.ems.pojo.EventLocation;

public class EventLocationMapper implements RowMapper<EventLocation> {

	@Override
	public EventLocation mapRow(ResultSet rs, int rowNum) throws SQLException {
		EventLocation eventLocation = new EventLocation();
		
		eventLocation.setEvent_id(rs.getInt("event_id"));
		eventLocation.setCity(rs.getString("city"));
		eventLocation.setAddress(rs.getString("address"));
		eventLocation.setDate(rs.getDate("date").toLocalDate());
		eventLocation.setCountry(rs.getString("country"));
		eventLocation.setImageUrl(rs.getString("imageurl"));
		eventLocation.setLoc_id(rs.getInt("loc_id"));
		eventLocation.setName(rs.getString("name"));
		eventLocation.setPrice(rs.getFloat("price"));
		eventLocation.setTime(rs.getString("time"));
		
		return eventLocation;
	}
}
