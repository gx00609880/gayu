package com.ems.service;

import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestBody;

import com.ems.dao.EventDAO;
import com.ems.entities.Location;
import com.ems.model.Event;

@Service
public class EventService {

	@Autowired
	EventDAO eventDAO;
	
	public boolean updateLocationCity(int locationId, String cityName) {
		return eventDAO.updateLocationCity(locationId, cityName);
	}
	
	public boolean deleteLocation(int locationId) {
		return eventDAO.deleteLocation(locationId);
	}
	
	public List<Location> searchByLocationCountry(String countryName){
		return eventDAO.searchByLocationCountry(countryName);
	}
	
	public boolean insertLocation(List<Location> locations) {
		return eventDAO.insertLocation(locations);
	}
	
	public com.ems.entities.Event getEventDetails(int eventId) {
		
		return  eventDAO.getAllEventDetails(eventId);
		
		
	}
	
	public List<com.ems.entities.Event> getAllEventDetails(){
		return  eventDAO.getAllEventDetails();
	}
	
	public boolean insertEventDetails(Event event) {
		
		com.ems.entities.Event event1 = new com.ems.entities.Event();
		event1.setImageUrl(event.getImageUrl());
		event1.setName(event.getName());
		event1.setPrice(event.getPrice());
		event1.setTime(event.getTime());
		LocalDate date = LocalDate.parse(event.getDate());
        event1.setDate(date);
        System.out.println(event.getLocation());
        Location location = new Location();
        location.setAddress(event.getLocation().getAddress());
        location.setCity(event.getLocation().getCity());
        location.setCountry(event.getLocation().getCountry());
        event1.setLocation(location);        
		
		return eventDAO.insertEventDetails(event1);
	}
}
