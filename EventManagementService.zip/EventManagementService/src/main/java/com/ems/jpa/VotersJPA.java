package com.ems.jpa;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ems.entities.Voters;

public interface VotersJPA extends JpaRepository<Voters, Integer> {

}
