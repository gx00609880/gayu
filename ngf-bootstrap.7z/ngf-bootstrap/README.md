# ng2f-bootstrap

This project contains custom twitter bootstrap files for an Angular Fundamentals course
