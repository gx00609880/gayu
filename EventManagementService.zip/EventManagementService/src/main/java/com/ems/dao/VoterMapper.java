package com.ems.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.ems.pojo.Voters;

public class VoterMapper implements RowMapper<Voters> {
	
	@Override
	public Voters mapRow(ResultSet rs, int rowNum) throws SQLException {
	
		Voters voters = new Voters();
		
		voters.setVoter_id(rs.getInt("voter_id"));
		voters.setVoter_name(rs.getString("name"));
		
		return voters;
	}

}
