class Product{
    constructor(private _prodId:number,private _prodName:string,private _prodPrice:number)
    {
        
    }
    public get prodId():number{
        return this._prodId;
    }
    public get prodName():string{
        return this._prodName;
    }
    public get prodPrice():number{
        return this._prodPrice;
    }
    public set prodId(prodId:number){
        this._prodId=prodId;
    }
    public set prodName(prodName:string){
        this._prodName=prodName;
    }
    public set prodPrice(prodPrice:number){
        this._prodPrice=prodPrice;
    }
    
}
var product=new Product(101,"Apple Watch",3243);
product.prodPrice=34453;
console.log(product.prodPrice);
