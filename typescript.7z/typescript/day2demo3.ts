import {TodoApp}from "./day2demo2";
class Abc extends TodoApp{

}