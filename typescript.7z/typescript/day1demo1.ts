var age:string="12";//when u pop up ,it shows any = no typeinference
let names:string|number="gayathri";//"|" is union
names=12;
//string-is a primitive type
//String-is a wrapper class
let veg:boolean[]=[false,true];//nested array
let fruits:[boolean,string,string]=[true,"abc","def"];//array
let [a,b,c]=fruits;//
function getData(name:string,age?:number){

}
getData("34");
/* for(let tmp in fruits)
{

    console.log(fruits[tmp]);
} */
for(let tmp of fruits)
{


    console.log(tmp);
}
function demo()
{

    if(true){
    var price:number=10.5;
    }
    console.log(price);
}
demo();

class Employee{

}
age="34";//typeinference
console.log(age);


