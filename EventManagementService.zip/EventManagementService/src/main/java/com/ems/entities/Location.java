package com.ems.entities;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToOne;

@Entity
public class Location {

	@Id //Primary Key Equalent
	@GeneratedValue
	private int locationId;
	private String address;
	private String city;
	private String country;
	
	/*@OneToOne
	private Event event;*/
	
	public Location() {
		// TODO Auto-generated constructor stub
	}
	
	public Location(int id,String address, String city, String country) {
		super();
		this.locationId = id;
		this.address = address;
		this.city = city;
		this.country = country;
		
	}

	@Override
	public String toString() {
		return "Location [locationId=" + locationId + ", address=" + address + ", city=" + city + ", country=" + country
				+ "]";
	}

	public int getLocationId() {
		return locationId;
	}

	public void setLocationId(int locationId) {
		this.locationId = locationId;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	

	
}
