package com.ems.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.ems.model.Session;

public class SessionMapper implements RowMapper<Session> {

	@Override
	public Session mapRow(ResultSet rs, int rowNum) throws SQLException {
		
		Session session = new Session();
		
		session.setDescription(rs.getString("description"));
		session.setDuration(rs.getInt("duration"));
		session.setId(rs.getInt("id"));
		session.setLevel(rs.getString("level"));
		session.setName(rs.getString("name"));
		session.setPresenter(rs.getString("presenter"));
		
		return session;
		//session.setVoters(voters);
		
		
		
		
		
		
	}
}
